import React from 'react'
import Destination from './destination'

export default function Hotels() {
  return (
    <div>
      <Destination/>
    </div>
  )
}
